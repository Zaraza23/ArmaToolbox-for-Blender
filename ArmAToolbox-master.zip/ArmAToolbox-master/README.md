# ArmAToolbox
Arma Toolbox for Blender
This is a collection of Python scripts for the Blender 3D package
that allows the user to create, import and export unbinarized 
Arma Engine .p3d files. 

# License
License
This program is free software; you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

As an exception to this, any files written while using this software
is not covered by this license. That includes .p3d files as well as
any other file written by this software.

